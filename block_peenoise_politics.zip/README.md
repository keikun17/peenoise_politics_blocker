Chrome Extension to replace the following words with pedobear:

- duterte
- du30
- pnoy
- marcos
- aquino
